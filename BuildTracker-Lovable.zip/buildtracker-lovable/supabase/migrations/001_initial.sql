-- BuildTracker Supabase Migration
-- Run this in your Supabase SQL Editor to set up all tables, RLS, and policies.

-- ══════════════════════════════════════════════════════════
-- 1. TABLES
-- ══════════════════════════════════════════════════════════

-- Projects
CREATE TABLE IF NOT EXISTS projects (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  address TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active',
  start_date TEXT NOT NULL,
  color TEXT NOT NULL DEFAULT '#01696F'
);

-- Phases
CREATE TABLE IF NOT EXISTS phases (
  id SERIAL PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  color TEXT NOT NULL DEFAULT '#01696F'
);

-- Tasks
CREATE TABLE IF NOT EXISTS tasks (
  id SERIAL PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  phase_id INTEGER REFERENCES phases(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  start_date TEXT NOT NULL,
  duration_weeks INTEGER NOT NULL DEFAULT 1,
  status TEXT NOT NULL DEFAULT 'upcoming',
  category TEXT NOT NULL DEFAULT 'General',
  notes TEXT NOT NULL DEFAULT '',
  sort_order INTEGER NOT NULL DEFAULT 0
);

-- Budgets
CREATE TABLE IF NOT EXISTS budgets (
  id SERIAL PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  original_value NUMERIC NOT NULL DEFAULT 0,
  notes TEXT DEFAULT ''
);

-- Cost Items (expenses, extras, labour, adhoc)
CREATE TABLE IF NOT EXISTS cost_items (
  id SERIAL PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('extra', 'expense', 'labour', 'adhoc')),
  category TEXT NOT NULL DEFAULT 'General',
  description TEXT NOT NULL,
  amount NUMERIC NOT NULL DEFAULT 0,
  date TEXT NOT NULL,
  reference TEXT DEFAULT '',
  supplier TEXT DEFAULT '',
  notes TEXT DEFAULT '',
  attachment_url TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  worker_name TEXT NOT NULL DEFAULT '',
  hours_worked REAL NOT NULL DEFAULT 0,
  day_rate REAL NOT NULL DEFAULT 0
);

-- Schedule Entries
CREATE TABLE IF NOT EXISTS schedule_entries (
  id SERIAL PRIMARY KEY,
  project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  task_description TEXT NOT NULL DEFAULT '',
  workers TEXT NOT NULL DEFAULT '',
  notes TEXT NOT NULL DEFAULT '',
  color TEXT NOT NULL DEFAULT '#DBEAFE',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  source_labour_id INTEGER
);

-- Schedule Absences
CREATE TABLE IF NOT EXISTS schedule_absences (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  worker_name TEXT NOT NULL DEFAULT '',
  reason TEXT NOT NULL DEFAULT 'Holiday',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Worker Profiles
CREATE TABLE IF NOT EXISTS worker_profiles (
  id SERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  default_day_rate NUMERIC NOT NULL DEFAULT 0,
  default_category TEXT NOT NULL DEFAULT '',
  default_supplier TEXT NOT NULL DEFAULT '',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, name)
);


-- ══════════════════════════════════════════════════════════
-- 2. ROW LEVEL SECURITY
-- ══════════════════════════════════════════════════════════

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE phases ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE budgets ENABLE ROW LEVEL SECURITY;
ALTER TABLE cost_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE schedule_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE schedule_absences ENABLE ROW LEVEL SECURITY;
ALTER TABLE worker_profiles ENABLE ROW LEVEL SECURITY;


-- ══════════════════════════════════════════════════════════
-- 3. RLS POLICIES
-- ══════════════════════════════════════════════════════════

-- Projects: users can only see/modify their own projects
CREATE POLICY "Users can view own projects"
  ON projects FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own projects"
  ON projects FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own projects"
  ON projects FOR UPDATE
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own projects"
  ON projects FOR DELETE
  USING (user_id = auth.uid());

-- Phases: access through project ownership
CREATE POLICY "Users can view phases of own projects"
  ON phases FOR SELECT
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can insert phases to own projects"
  ON phases FOR INSERT
  WITH CHECK (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can update phases of own projects"
  ON phases FOR UPDATE
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can delete phases of own projects"
  ON phases FOR DELETE
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

-- Tasks: access through project ownership
CREATE POLICY "Users can view tasks of own projects"
  ON tasks FOR SELECT
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can insert tasks to own projects"
  ON tasks FOR INSERT
  WITH CHECK (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can update tasks of own projects"
  ON tasks FOR UPDATE
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can delete tasks of own projects"
  ON tasks FOR DELETE
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

-- Budgets: access through project ownership
CREATE POLICY "Users can view budgets of own projects"
  ON budgets FOR SELECT
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can insert budgets to own projects"
  ON budgets FOR INSERT
  WITH CHECK (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can update budgets of own projects"
  ON budgets FOR UPDATE
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can delete budgets of own projects"
  ON budgets FOR DELETE
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

-- Cost Items: access through project ownership
CREATE POLICY "Users can view costs of own projects"
  ON cost_items FOR SELECT
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can insert costs to own projects"
  ON cost_items FOR INSERT
  WITH CHECK (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can update costs of own projects"
  ON cost_items FOR UPDATE
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can delete costs of own projects"
  ON cost_items FOR DELETE
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

-- Schedule Entries: access through project ownership
CREATE POLICY "Users can view schedule of own projects"
  ON schedule_entries FOR SELECT
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can insert schedule to own projects"
  ON schedule_entries FOR INSERT
  WITH CHECK (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can update schedule of own projects"
  ON schedule_entries FOR UPDATE
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

CREATE POLICY "Users can delete schedule of own projects"
  ON schedule_entries FOR DELETE
  USING (project_id IN (SELECT id FROM projects WHERE user_id = auth.uid()));

-- Schedule Absences: user-scoped
CREATE POLICY "Users can view own absences"
  ON schedule_absences FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own absences"
  ON schedule_absences FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own absences"
  ON schedule_absences FOR UPDATE
  USING (user_id = auth.uid());

CREATE POLICY "Users can delete own absences"
  ON schedule_absences FOR DELETE
  USING (user_id = auth.uid());

-- Worker Profiles: user-scoped
CREATE POLICY "Users can view own worker profiles"
  ON worker_profiles FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can insert own worker profiles"
  ON worker_profiles FOR INSERT
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own worker profiles"
  ON worker_profiles FOR UPDATE
  USING (user_id = auth.uid());

CREATE POLICY "Users can delete own worker profiles"
  ON worker_profiles FOR DELETE
  USING (user_id = auth.uid());
